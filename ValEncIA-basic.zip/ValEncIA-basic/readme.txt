This folder contains the publicly available simplified version of ValEncIA-IVP.

For further information about ValEncIA-IVP, please have a look at the included copy of:
E. Auer, A. Rauh, E. P. Hofer, and W. Luther. "Validated Modeling of Mechanical Systems with SmartMOBILE: Improvement of Performance by ValEncIA-IVP". In Proc. of Dagstuhl Seminar 06021: Reliable Implementation of Real Number Algorithms: Theory and Practice, Lecture Notes in Computer Science, Springer-Verlag, 2008.

Since the release of the basic version (ValEncIA-IVP_FREE.zip), we have made several important modifications. Especially, we have implemented a C++ program which includes a new exponential enclosure approach. It prevents the growth of the interval diameters of the desired state enclosures especially for asymptotically stable systems (with dominant linear dynamics) if the growth is caused by overestimation.

You can find a short description of the exponential enclosure approach in:
Rauh, A.; Auer, E.; Minisini, J.; Hofer, E.P.: Extensions of ValEncIA-IVP for Reduction of Overestimation, for Simulation of Differential Algebraic Systems, and for Dynamical Optimization, Proc. of the 6th Intl. Congress on Industrial and Applied Mathematics, Minisymposium Taylor Model Methods and Interval Methods – Applications, Zurich, Switzerland, 2007. PAMM, vol. 7(1), pp. 1023001–1023002, available online: http://www3.interscience.wiley.com/cgi-bin/fulltext/117925744/PDFSTART

For your convenience, we have attached C++ files for two different applications which highlight the new features and the parameterization of the above-mentioned extension of ValEncIA-IVP for both scalar ODEs and multi-dimensional problems.

1) An example for the scalar case: a simple electrical circuit:
    "ValEncIA-IVP_0.92_4_exp_RC.cpp" with the state equation
    \dot{x}_1 = (-1./(R*C))*(x_1-1.0);

2) An example for the multi-dimensional case: the catalytic reactor described in the paper presented at the ICIAM 2007, see above.
    "ValEncIA-IVP_0.92_4_exp_cat.cpp"

In contrast to the basic version of ValEncIA-IVP (without the feature of exponential state enclosures), the GNU Scientific Library GSL has to be installed on your system. Please use the version gsl-1.11 (or later) since we have not tested the program with older versions. Furthermore, it is essential to use the latest version of FADBAD++ (version 2.1). You can find detailed instructions how to compile the new version of ValEncIA-IVP in line 12 of the files "ValEncIA-IVP_0.92_4_exp_RC.cpp" and "ValEncIA-IVP_0.92_4_exp_cat.cpp". Note that "/home/andreas/Profil-2.0.4/" indicates the folder in which you have installed your version of Profil/BIAS. You can replace Profil/BIAS 2.0.4 with the latest version of this package.

Compared to the basic version, the major differences between these two versions of ValEncIA-IVP are:

I) The state equations have to be specified only once in the template "system".

II) The exponential enclosure approach tries to decouple the state equations algorithmically such that each state equation only depends upon a single state variable. For linear systems the decoupling routine is identical to a numerical transformation of the state equations into real Jordan normal form. Since this operation is essential to tighten the state enclosures, please do NOT modify the template "Trafo" as well as the matrices "T_MAT", "IT_MAT", and the vector "shift_x". The output files "x_app_numeric.txt" and "R_plot_ex.txt" contain the approximate solution as well as the state enclosures in the original coordinate system.

III) In order to reduce the computational effort, you can reformulate linear system models such that they are given in Jordan normal form using an arbitrary computer algebra system before the use of ValEncIA-IVP. Note that this step is optional.

IV) An additional switch to deactivate the exponential enclosure approach is available
    valencia_classic=1;     // means that the original version of ValEncIA-IVP is executed (almost identical to the version included in ValEncIA-IVP_FREE.zip)
    valencia_classic=0;     // means that exponential enclosures are determined in ValEncIA-IVP

V) All state variables and system parameters (time-invariant as well as time-varying) have to be specified as components of the state vector, i.e., "n" corresponds to the number of states + parameters. Please have a look at the definition of
    initial_encl(1) = Hull( 0.000,  0.000);      // Initial state
    initial_encl(2) = Hull(10.000, 15.300);    // R
    initial_encl(3) = Hull( 0.010,  0.030);      // C
in the file "ValEncIA-IVP_0.92_4_exp_RC.cpp". For time-invariant parameters p = const, additional state equations dp/dt = 0 have to be introduced. I have done this for the parameters R and C of the scalar system mentioned in 1). Please do not modify the definition of "p" in line 361. The vector "par_vec" no longer contains any system parameters. However, it is still required for internal purposes.

VI) For asymptotically stable systems, this new version of ValEncIA-IVP can deal with significantly larger uncertainties (usually also with larger step-sizes) than the basic routine. You can, for example, use line 406 instead of 405 in "ValEncIA-IVP_0.92_4_exp_cat.cpp" to verify my statement.

You can find further information about the exponential enclosure approach in a proceedings paper of SCAN 2012, published in Reliable Computing:
Andreas Rauh, Ramona Westphal,  Harald Aschemann, and Ekaterina Auer, Exponential Enclosure Techniques for the Computation of Guaranteed State Enclosures in ValEncIA-IVP, pp. 66-90:
https://interval.louisiana.edu/reliable-computing-journal/volume-19/reliable-computing-19-pp-066-090.pdf

as well as in

Andreas Rauh, Ramona Westphal, Harald Aschemann, Ekaterina Auer: Exponential Enclosure Techniques for Initial Value Problems with Multiple Conjugate Complex Eigenvalues,
In: Nehmeier M., Wolff von Gudenberg J., Tucker W. (eds) Scientific Computing, Computer Arithmetic, and Validated Numerics. SCAN 2014. Lecture Notes in Computer Science, vol 9553.
https://link.springer.com/chapter/10.1007%2F978-3-319-31769-4_20

Unfortunately, the above-mentioned recent developments of the exponential enclosure technique (the references corresponding to SCAN2012 and SCAN 2014) are not yet publicly available as C++ sources. With respect to these developments, we are still working on a non-optimized prototypic Matlab implementation (available separately on https://github.com/ValEncIA-IVP/exponential; for further information, you may want to have a look at our workshop given during ECC 2015. The corresponding files are available here: https://www.interval-methods.de/seminars).


Some further information that may be of interest to you: You may consider to have a closer look at VERICOMP. VERICOMP is a system to compare and assess different verified IVP solvers (see the references below):
vericomp.fiw.hs-wismar.de 
https://interval.louisiana.edu/reliable-computing-journal/volume-22/reliable-computing-22-pp-078-103.pdf
