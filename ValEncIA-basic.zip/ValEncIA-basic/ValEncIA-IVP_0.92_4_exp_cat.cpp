// ---------------------- ValEncIA-IVP ------------------------------ //
/* Note that use of ValEncIA-IVP which can be obtained free on www.valencia-ivp.com is only permitted for private and academic purposes provided that proper reference to the authors of ValEncIA-IVP is given in any work employing this software. For use of parts of the software in commercial products, written permission of the authors is required, see contact information below. Do not hesitate to contact the authors Andreas Rauh and Ekaterina Auer if you have any comments or suggestions concerning the web page www.valencia-ivp.vom, the applied algorithms, or the provided software.

In order to compile the source code of ValEncIA-IVP, the interval arithmetic library PROFIL/BIAS, the automatic differentiation package FADBAD++, as well as a compatible C++ compiler are required. To obtain these libraries, see the web pages of the corresponding developers. If you want to apply ValEncIA-IVP, please also observe the terms of use of the above-mentioned libraries.

ValEncIA-IVP has been developed using PROFIL/BIAS 2.0.2, FADBAD++ 1.4 and gcc4.0.2 under SuSe Linux 10.0.
ValEncIA-IVP has been tested with PROFIL/BIAS 2.0.4. This version of PROFIL/BIAS is required for use of gcc4.1.

If you would like the authors of ValEncIA-IVP to publish your experience with ValEncIA-IVP in a special section on the web page www.valencia-ivp.com, please feel free to send us any comments together with a short description of your application and research areas. 


g++ -I/home/andreas/Profil-2.0.4/include/ -I/home/andreas/Profil-2.0.4/FADBAD++/ -L/home/andreas/Profil-2.0.4/lib/  ValEncIA-IVP_0.92_4_exp_cat.cpp -lProfilPackages -lProfil -lBias -llr -lm -lgsl -lgslcblas -O -o ValEncIA-IVP_0.92_4_exp_cat


-------------------

AUTHORS OF VALENCIA-IVP:

Andreas Rauh
Institute of Measurement, Control, and Microtechnology
University of Ulm
D-89069 Ulm, Germany
Andreas.Rauh@uni-ulm.de


Ekaterina Auer
Faculty of Engineering, IIIS
University of Duisburg-Essen
D-47048 Duisburg, Germany
Auer@inf.uni-due.de
*/

// ---------------------- ValEncIA-IVP ------------------------------ //

// Last modification of this file: March 28, 2008: Andreas Rauh
// 
// Note that this is a preliminary version in which further improvements with respect to computing will be included
 

#include "Interval.h"
#include "IntervalMatrix.h"
#include "IntervalVector.h"
#include "Matrix.h"
#include "Vector.h"
#include "IntegerVector.h"
#include "LSS.h"

#include "BIAS/Bias0.h"
#include "Functions.h"
#include "math.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include "vector"

#include <gsl/gsl_matrix.h>
#include <gsl/gsl_matrix_char.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multifit.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_sort.h>

#include <iostream>
#include "stdio.h"
using namespace std;

#define pow Power
#define sqr Sqr
#define exp Exp
#define log Log
#define sqrt Sqrt
#define sin Sin
#define cos Cos
#define tan Tan
#define asin ArcSin
#define acos ArcCos
#define atan ArcTan
//#define BaseType INTERVAL

#include "fadbad.h"
#include "tadiff.h"
#include "fadiff.h"
#include "badiff.h"

using namespace fadbad;

//#undef BaseType
#undef pow
#undef sqr
#undef exp
#undef log
#undef sqrt
#undef sin
#undef cos
#undef tan
#undef asin
#undef acos
#undef atan

bool mode_old=1;
INTERVAL tinf;
INTERVAL_VECTOR coeff_exp_init;
INTERVAL_MATRIX T_MAT, IT_MAT;

VECTOR shift_x;

//Definition of vectors
typedef  vector< REAL > REALVEC;
typedef  vector< F<REAL> > FREALVEC;
typedef  vector< INTERVAL > INTERVALVEC;
typedef  vector< F<INTERVAL> > FINTERVALVEC;



// Definition of state equations for computation of non-validated approximate solution
namespace
{ template<typename T1, typename T2>
  T1 system(T1 x_vec, T1 par, T2 x, int j)
  {
    T1 f(sizeof(x_vec));
    T2 x_1;
    T2 x_2;
    T2 u_var;

    double k1_par, k2_par, k3_par;
    k1_par = 1.0;
    k2_par = 10.0;
    k3_par = 1.0;

    x_1 = x_vec[0];
    x_2 = x_vec[1];
    u_var = x_vec[2];

    f[0] = (-k1_par*u_var*x_1 + k2_par*u_var*x_2);
    f[1] = (+k1_par*u_var*x_1 + (-k3_par-(k2_par-k3_par)*u_var)*x_2);
    f[2] = 0.0;

    return f;
  }
}


namespace
{ template<typename T1, typename T2>
  T1 Trafo(T2 TRA_MAT, T1 x_vec, int n)
  {
	T1 f(sizeof(x_vec));
	int i,j;

	for (i=1;i<=n;i++)
	{
		f[i-1] = 0.0;
		for (j=1;j<=n;j++)	
		{
		f[i-1] = f[i-1] + TRA_MAT(i,j)*x_vec[j-1];
		}
	}
	return f;
  }
}


FINTERVALVEC system_F( FINTERVALVEC x0, int n )
// FREALVEC system_F( FREALVEC x0, int n )  
  {
	FINTERVALVEC f_x0(n);
// 	FREALVEC f_x0(n);
	f_x0 = system(x0, x0, x0[0], 0);
	return f_x0;
  }



REAL state_eq_i( VECTOR states, VECTOR parameters, REAL t_int, int j, int n, int p) 
  {
    REAL f;
    REALVEC x(n), fvec(n);
    REALVEC par(p);

    for(int i=1;i<=n;i++)
      {
	x[i-1] = states(i);
      }

    for(int i=1;i<=p;i++)
      {
	par[i-1] = parameters(i);
      }

x = Trafo(Mid(T_MAT), x, n);
for(int i=1;i<=n;i++)
      {
	x[i-1] = x[i-1] + shift_x(i);
      }

//---------------------------------
    fvec = system(x, par, x[0], j);
    fvec = Trafo(Mid(IT_MAT), fvec, n);
    f = fvec[j-1];
//---------------------------------
    return f;
  }


// Definition of state equations for evaluation at interval midpoints (mean-value rule)
  INTERVAL state_eq_mid_i(VECTOR states, VECTOR dstates, INTERVAL t_int, INTERVAL_VECTOR parameters, INTERVAL_VECTOR R_plot, int j, int n, int p) 
  {
    INTERVAL f;
    INTERVALVEC x(n), x_tmp(n), fvec(n);
    INTERVALVEC par(p);

    INTERVAL t_diff(Mid(t_int)-tinf);

    for(int i=1;i<=p;i++)
      {
	par[i-1] = Hull(Mid(parameters(i)));
      }

if (mode_old)
      {
    for(int i=1;i<=n;i++)
      {
	x[i-1] = states(i)+t_diff*dstates(i)+Mid(R_plot(i));
	x_tmp[i-1] = x[i-1];
      }
}
else
{
for(int i=1;i<=n;i++)
      {
	x[i-1] = par[i-1]*Exp(t_diff*Mid(R_plot(i)));
	x_tmp[i-1] = x[i-1];
      }
}

x = Trafo(T_MAT, x, n);
for(int i=1;i<=n;i++)
      {
	x[i-1] = x[i-1] + shift_x(i);
      }

//---------------------------------
    fvec = system(x, par, x[0], j);
    fvec = Trafo(IT_MAT, fvec, n);
    f = fvec[j-1];

if (!mode_old)
	{ f = f/(x_tmp[j-1]); }

//---------------------------------
    return f;
  }


// Definition of state equations for evaluation of mean-value rule (with automatic differentiation)
  F<INTERVAL> state_eq_F_i(VECTOR states, VECTOR dstates, INTERVAL t_int1, INTERVAL_VECTOR parameters, INTERVAL_VECTOR R_plot, int j, int n, int p) 
  {
    F<INTERVAL> f;
    F<INTERVAL> t_int;
    FINTERVALVEC x(n), x_tmp(n), fvec(n), R(n), par(p);

    F<INTERVAL> t_diff;

//-------------------------------
    for(int i=1;i<=n;i++)
      {
	R[i-1] = R_plot(i);
      }

    for(int i=1;i<=p;i++)
      {
	par[i-1] = parameters(i);
      }

    t_int = t_int1;
//-------------------------------
//First order derivatives:
    for(int i=1;i<=n;i++)
      {
	R[i-1].diff(i-1,n+p+1);
      }

    for(int i=1;i<=p;i++)
      {
	par[i-1].diff(i+n-1,n+p+1);
      }

    t_int.diff(n+p,n+p+1);
//---------------------------------
    t_diff = t_int-tinf; 

if (mode_old)
      {
    for(int i=1;i<=n;i++)
      {
	x[i-1] = states(i)+t_diff*dstates(i)+R[i-1];
	x_tmp[i-1] = x[i-1];
      }
}
else
{
for(int i=1;i<=n;i++)
      {
	x[i-1] = par[i-1]*Exp(t_diff*(R[i-1]));
	x_tmp[i-1] = x[i-1];
      }
}

x = Trafo(T_MAT, x, n);
for(int i=1;i<=n;i++)
      {
	x[i-1] = x[i-1] + shift_x(i);
      }

//---------------------------------
    fvec = system(x, par, x[0], j);
    fvec = Trafo(IT_MAT, fvec, n);
    f = fvec[j-1];

if (!mode_old)
	{ f = f/(x_tmp[j-1]); }

//---------------------------------
    return f;
  }




//	Funktionen:
//	============================================================================================================================
INTERVAL_VECTOR d_R_computation(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR p_vec, INTERVAL t_int, INTERVAL_VECTOR R_plot, int n, int p, bool use_monotonicity_test, int Max_split);

INTERVAL MVR_d_R_i(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR p_vec, INTERVAL t_int, INTERVAL_VECTOR R_plot, INTERVAL_VECTOR& gradient_eq_i, int n, int p, int eq_i);

void MonotonicityTestInf(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR& R_vec_mon_inf, INTERVAL_VECTOR& p_vec_mon_inf, INTERVAL& t_int_mon_inf, INTERVAL_VECTOR& gradient_eq_i_inf, VECTOR& lower_bounds, int n, int p, int eq_i);

void MonotonicityTestSup(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR& R_vec_mon_sup, INTERVAL_VECTOR& p_vec_mon_sup, INTERVAL& t_int_mon_sup, INTERVAL_VECTOR& gradient_eq_i_sup, VECTOR& upper_bounds, int n, int p, int eq_i);

void compute_R(int& Number, int& Number_min, int& Number_max, INTERVAL_VECTOR t1_int, INTERVAL_MATRIX& R_plot, INTERVAL_MATRIX& d_R, INTEGER_VECTOR& valid_step, INTERVAL_VECTOR par_vec, INTERVAL_VECTOR initial_encl, INTERVAL_MATRIX x_app_numeric_int, MATRIX x_app_numeric_low, MATRIX dx_app_numeric1, double Stepsize, double g, int number_rep, int number_rep_max, bool use_monotonicity_test, int Max_split, bool& error, bool& ready, int n, int p);

void compute_rot(INTERVAL_VECTOR initial_encl, int n);

//	============================================================================================================================

//	Global Variables:
//	---------------------------------------------------------------------------------------------------
const double EPS=1E-200;
const double EPS_EXP=0; //1E-200;
bool Intersection_exists;
bool break_diam_R_large;
bool save_every_step=0;  // save intermediate results if save_every_step==1
bool valencia_classic=0;
double max_diam_R=1000.;
int EXP_RUN=1;

bool DEBUG=0;

//	---------------------------------------------------------------------------------------------------

int main()
{
  int n = 3;   // Dimension of state vector
  int p = n;   // Dimension of parameter vector 

  int Max_split = 0;
  int Max_split_calc = 10;  // Maximum number of splittings in range computation

  double Process_time = 10.000;
  double Stepsize     = 0.005;

  bool use_monotonicity_test = 0;

  int Number=(int)(Process_time/Stepsize+1.0);

  int Number_min=1, Number_max=1, i, j;
  int number_rep = 0, number_rep_max = 5;	// Maximal number of reevaluations, if error bounds are not large enough
                                        // (falls Number_max < Number_max_old)

  double g =  0.999;   // precision of solution: relative variation between two iterations has to be smaller than (1-g)

  INTERVAL_VECTOR  t1_int(Number), initial_encl(n), par_vec(p);
  VECTOR	   x_app_numeric(n), dx_app_numeric(n), par_vec_double(p);
  MATRIX           x_app_numeric_all(n,Number+1), x_app_numeric_low(n,Number), x_app_numeric_upp(n,Number), dx_app_numeric1(n,Number);

  INTERVAL_MATRIX  R_plot(n,Number), X_plot(n,Number), x_app_numeric_int(n,Number), d_R(n,Number);

  INTEGER_VECTOR valid_step(Number);

  Initialize(valid_step,0);

  bool error = 0, ready = 0;

  //	---------------------------------------------------------------------------------------------------	

  // specification of initial states

  Resize(shift_x,n);
  Initialize(shift_x,0.0);

  initial_encl(1) = Hull( 1.000,  1.000);
  initial_encl(2) = Hull( 0.000,  0.000); 
  initial_encl(3) = Hull( 0.500,  0.500); 
//   initial_encl(3) = Hull( 0.500,  0.500) + SymHull(0.5); 

  compute_rot(initial_encl, n);

  INTERVALVEC x_init(n);
  initial_encl = initial_encl - shift_x;

  for (i=1;i<=n;i++)	
  {
	x_init[i-1] = initial_encl(i);
  }
  x_init = Trafo(IT_MAT, x_init, n);
  for (i=1;i<=n;i++)	
  {
	initial_encl(i) = x_init[i-1];
  }
  cout << "initial_encl = " << initial_encl << endl;

  for (i=1; i<=p; i++)
  {  par_vec(i) = Hull(0.000); }

  //	---------------------------------------------------------------------------------------------------	
  //	measurement of computing time:
  long s_time, e_time, duration; 
  s_time=time(NULL); 


  //	--------------------------------------------------------------------------------------------------------------------------
  //	Computation of time intervals:
  for(i=1;i<=Number;i++)
    {
      t1_int(i) = Hull((i-1)*Stepsize,i*Stepsize);
    }

  //	--------------------------------------------------------------------------------------------------------------------------
  //	Approximate solution (numeric):
  //	--------------------------------------------------------------------------------------------------------------------------

  x_app_numeric = Mid(initial_encl);
  par_vec_double = Mid(par_vec); 

  SetCol(x_app_numeric_all,1,x_app_numeric); 

  for(i=1;i<=Number;i++) 
    {
      for(j=1;j<=n;j++)
	{
	  dx_app_numeric(j) = state_eq_i(x_app_numeric,par_vec_double,Inf(t1_int(i)),j,n,p); 
	}
      x_app_numeric = x_app_numeric + Stepsize*dx_app_numeric; 
      SetCol(x_app_numeric_all,i+1,x_app_numeric); 
    }

  for(i=1;i<=Number;i++)
    {
      SetCol(x_app_numeric_low,i,Col(x_app_numeric_all,i));
      SetCol(x_app_numeric_upp,i,Col(x_app_numeric_all,i+1));
    }

  for(i=1;i<=Number;i++)
    {
      SetCol(x_app_numeric_int,i,Hull(Col(x_app_numeric_low,i),Col(x_app_numeric_upp,i)));
      SetCol(dx_app_numeric1,i,(Col(x_app_numeric_upp,i)-Col(x_app_numeric_low,i))/Diam(t1_int(i)));
    }

  
  //	--------------------------------------------------------------------------------------------------------------------------
  //	Computation of interval enclosures:
  //	--------------------------------------------------------------------------------------------------------------------------

  // initialization
  Initialize(d_R,SymHull(1.0));
  for (j=1;j<=Number;j++)
    {
      if (j==1)
	{
	  SetCol(R_plot,j,initial_encl-Col(x_app_numeric_low,1)+Stepsize*Col(d_R,j));
	}
      else
	{
	  SetCol(R_plot,j,Col(R_plot,j-1)+Stepsize*Col(d_R,j));
	}
    }
 

  // iteration formula of ValEncIA-IVP (without iterative range computation)

if (valencia_classic==1)
{
  EXP_RUN=0;
  compute_R(Number, Number_min, Number_max, t1_int, R_plot, d_R, valid_step, par_vec, initial_encl, x_app_numeric_int, x_app_numeric_low, dx_app_numeric1, Stepsize, g, number_rep, number_rep_max, use_monotonicity_test, Max_split, error, ready, n, p);

 if ((Max_split_calc>0)||(use_monotonicity_test==1))
   {
     Number_min = 1;
     error = 0;
     ready = 0;
     Max_split = Max_split_calc;
     use_monotonicity_test=1;
     compute_R(Number, Number_min, Number_max, t1_int, R_plot, d_R, valid_step, par_vec, initial_encl, x_app_numeric_int, x_app_numeric_low, dx_app_numeric1, Stepsize, g, number_rep, number_rep_max, use_monotonicity_test, Max_split, error, ready, n, p);
   }
}
else
{
  EXP_RUN=1;
  compute_R(Number, Number_min, Number_max, t1_int, R_plot, d_R, valid_step, par_vec, initial_encl, x_app_numeric_int, x_app_numeric_low, dx_app_numeric1, Stepsize, g, number_rep, number_rep_max, use_monotonicity_test, Max_split, error, ready, n, p);


  // iteration formula of ValEncIA-IVP (with iterative range computation)
 if ((Max_split_calc>0)||(use_monotonicity_test==1))
   {
     DEBUG=0;
     EXP_RUN=0;
     Number_min = 1;
     error = 0;
     ready = 0;
     Max_split = Max_split_calc;
     use_monotonicity_test=1;
     compute_R(Number, Number_min, Number_max, t1_int, R_plot, d_R, valid_step, par_vec, initial_encl, x_app_numeric_int, x_app_numeric_low, dx_app_numeric1, Stepsize, g, number_rep, number_rep_max, use_monotonicity_test, Max_split, error, ready, n, p);

     DEBUG=0;
     EXP_RUN=1;
     Number_min = 1;
     error = 0;
     ready = 0;
     Max_split = Max_split_calc;
     use_monotonicity_test=1;
     compute_R(Number, Number_min, Number_max, t1_int, R_plot, d_R, valid_step, par_vec, initial_encl, x_app_numeric_int, x_app_numeric_low, dx_app_numeric1, Stepsize, g, number_rep, number_rep_max, use_monotonicity_test, Max_split, error, ready, n, p);
   }
}	

  //	--------------------------------------------------------------------------------------------------------------------------
  //	save simulation results in text files
  //	--------------------------------------------------------------------------------------------------------------------------

  if (!Intersection_exists)
    printf("error: since no intersection of different solution methods exists/ Iteration does not converge!");
	
  if (error == 1)
    printf("Condition not fulfilled: bounds are getting larger at time-step! %d\n",Number_max);

  //	Computation of state enclosures:
  for (i=1;i<=Number_max;i++)
    {
      SetCol(X_plot,i,Col(R_plot,i)+Col(x_app_numeric_all,i+1));	      
    }
	
  FILE *file_x_app_numeric;
  FILE *file_R_plot;
  FILE *file_R_plot_ex;
  file_x_app_numeric = fopen("x_app_numeric.txt","w");
  file_R_plot = fopen("R_plot.txt","w");
  file_R_plot_ex = fopen("R_plot_ex.txt","w");

  printf("Writing File(s) ...\n\n");
	
  //	---------------------------------------------------------------------
  //	structure of data in R_plot:
  //	[t_int  inf(R1_plot)  sup(R1_plot)  ...  inf(Rn_plot)  sup(Rn_plot)]
  //	---------------------------------------------------------------------
	

REALVEC x_app_tmp(n);
INTERVALVEC X_plot_tmp(n);

  for (i=1;i<=Number_max;i++)
    {
      fprintf(file_x_app_numeric,"%.10e \t",Sup(t1_int(i)));
      fprintf(file_R_plot,"%.10e \t",Sup(t1_int(i)));
      fprintf(file_R_plot_ex,"%.10e \t",Sup(t1_int(i)));

	for (j=1;j<=n;j++)	
	{
	x_app_tmp[j-1]  = x_app_numeric_all(j,i+1);
	X_plot_tmp[j-1] = X_plot(j,i);
	}
	x_app_tmp = Trafo(Mid(T_MAT), x_app_tmp, n);
	X_plot_tmp = Trafo(T_MAT, X_plot_tmp, n);

      if(n>1)
	{
	  for(j=1;j<n;j++)
	    {
	      fprintf(file_x_app_numeric,"%.10e \t ",x_app_tmp[j-1]+shift_x(j));
	      fprintf(file_R_plot,"%.10e \t %.10e \t",Inf(R_plot(j,i)),Sup(R_plot(j,i)));
	      fprintf(file_R_plot_ex,"%.10e \t %.10e \t",Inf(X_plot_tmp[j-1]+shift_x(j)),Sup(X_plot_tmp[j-1]+shift_x(j)));
	    }
	}
      fprintf(file_x_app_numeric,"%.10e \n",(x_app_tmp[n-1]+shift_x(j)));
      fprintf(file_R_plot,"%.10e \t %.10e \n",Inf(R_plot(n,i)),Sup(R_plot(n,i)));
      fprintf(file_R_plot_ex,"%.10e \t %.10e \n",Inf(X_plot_tmp[n-1]+shift_x(j)),Sup(X_plot_tmp[n-1]+shift_x(j)));
    }

  //	Output of computing time:
  e_time=time(NULL); 
  duration=(e_time-s_time); 
  printf("Required computing time: %d seconds\n",duration);

  fclose(file_x_app_numeric);
  fclose(file_R_plot);
  fclose(file_R_plot_ex);
		
  return 0;
}


// ====================================================================================================================
// Functions and approximate solution
// ====================================================================================================================




INTERVAL_VECTOR d_R_computation(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR p_vec, INTERVAL t_int, INTERVAL_VECTOR R_plot, int n, int p, bool use_monotonicity_test, int Max_split) 
{ 
  VECTOR lower_bounds(n), upper_bounds(n);
  INTERVAL_VECTOR d_R(n), d_R_MP(n), d_R_MON(n), gradient_eq_i(n+p+1), gradient_eq_i_inf(n+p+1), gradient_eq_i_sup(n+p+1);
  INTERVAL_VECTOR R_vec_mon_inf(n), p_vec_mon_inf(p), R_vec_mon_sup(n), p_vec_mon_sup(p);
  INTERVAL t_int_mon_inf, t_int_mon_sup;
  int eq_i, i, cnt;

  INTERVAL_MATRIX states_inf(n+p+1,Max_split+1), grad_inf(n+p+1,Max_split+1), states_sup(n+p+1,Max_split+1), grad_sup(n+p+1,Max_split+1);
  INTERVAL_VECTOR tmp_vec(n+p+1), candidate1(n+p+1), candidate2(n+p+1);
  VECTOR out_inf(Max_split+1), out_sup(Max_split+1);
  double best_inf, best_sup, best_sensitivity;
  int best_interval, best_component;

  for(eq_i=1;eq_i<=n;eq_i++)
    {
      d_R_MP(eq_i)= MVR_d_R_i(x_app_vec, dx_app_vec, p_vec, t_int, R_plot, gradient_eq_i, n, p, eq_i);

      if (use_monotonicity_test==1)
	{
	  lower_bounds(eq_i) = Inf(d_R_MP(eq_i));
	  upper_bounds(eq_i) = Sup(d_R_MP(eq_i));

	  gradient_eq_i_inf = gradient_eq_i;
	  gradient_eq_i_sup = gradient_eq_i;
      
	  R_vec_mon_inf = R_plot;
	  p_vec_mon_inf = p_vec;
	  t_int_mon_inf = t_int;

	  R_vec_mon_sup = R_plot;
	  p_vec_mon_sup = p_vec;
	  t_int_mon_sup = t_int;

	  MonotonicityTestInf(x_app_vec, dx_app_vec, R_vec_mon_inf, p_vec_mon_inf, t_int_mon_inf, gradient_eq_i_inf, lower_bounds, n, p, eq_i);
	  SetCol(grad_inf,1,gradient_eq_i_inf);
	  for(i=1;i<=n;i++)
	    {
	      tmp_vec(i) = R_vec_mon_inf(i); 
	    }
	  for(i=1;i<=p;i++)
	    {
	      tmp_vec(i+n) = p_vec_mon_inf(i); 
	    }
	  tmp_vec(n+p+1) = t_int_mon_inf;
	  SetCol(states_inf,1,tmp_vec);
	  Initialize(out_inf,lower_bounds(eq_i));

	  for(cnt=1;cnt<=Max_split;cnt++)
	    {
	      // determine index of candidate to be split (smallest infimum in out_inf)
	      best_inf = out_inf(1);
	      best_interval = 1;
	      for(i=1;i<=cnt;i++)
		{
		  if (out_inf(i)<best_inf)
		    {
		      best_inf = out_inf(i);
		      best_interval = i;
		    }
		}
	      
	      gradient_eq_i_inf = Col(grad_inf,best_interval);
	      candidate1 = Col(states_inf,best_interval);
	      candidate2 = Col(states_inf,best_interval);
	      if (Max(Diam(candidate1))<1e-10)
		{
		  break;
		}
	      
	      best_component = 1;
	      best_sensitivity = Diam(gradient_eq_i_inf(1))*Diam(candidate1(1)); 
	      for(i=1;i<=n+p+1;i++)
		{
		  if ((Diam(gradient_eq_i_inf(i))*Diam(candidate1(i)))>best_sensitivity)
		    {
		      best_sensitivity = (Diam(gradient_eq_i_inf(i))*Diam(candidate1(i)));
		      best_component = i;
		    }
		}
	      candidate1(best_component) = Hull(Inf(candidate1(best_component)),Mid(candidate1(best_component))); 
	      candidate2(best_component) = Hull(Mid(candidate2(best_component)),Sup(candidate2(best_component)));
	      
	      for(i=1;i<=n;i++)
		{
		  R_vec_mon_inf(i) = candidate1(i);
		}
	      for(i=1;i<=p;i++)
		{
		  p_vec_mon_inf(i) = candidate1(i+n); 
		}
	      t_int_mon_inf = candidate1(n+p+1);

	      MonotonicityTestInf(x_app_vec, dx_app_vec, R_vec_mon_inf, p_vec_mon_inf, t_int_mon_inf, gradient_eq_i_inf, lower_bounds, n, p, eq_i);
	      SetCol(grad_inf,best_interval,gradient_eq_i_inf);
	      SetCol(states_inf,best_interval,candidate1);
	      out_inf(best_interval) = lower_bounds(eq_i);

	      for(i=1;i<=n;i++)
		{
		  R_vec_mon_inf(i) = candidate2(i);
		}
	      for(i=1;i<=p;i++)
		{
		  p_vec_mon_inf(i) = candidate2(i+n); 
		}
	      t_int_mon_inf = candidate2(n+p+1);

	      MonotonicityTestInf(x_app_vec, dx_app_vec, R_vec_mon_inf, p_vec_mon_inf, t_int_mon_inf, gradient_eq_i_inf, lower_bounds, n, p, eq_i);
	      
	      SetCol(grad_inf,cnt+1,gradient_eq_i_inf);
	      SetCol(states_inf,cnt+1,candidate2);
	      out_inf(cnt+1) = lower_bounds(eq_i);
	    }
	  lower_bounds(eq_i) = Min(out_inf);

	  ////////////////////////////////////////////////////////////////////////

	  MonotonicityTestSup(x_app_vec, dx_app_vec, R_vec_mon_sup, p_vec_mon_sup, t_int_mon_sup, gradient_eq_i_sup, upper_bounds, n, p, eq_i);
	  SetCol(grad_sup,1,gradient_eq_i_sup);
	  for(i=1;i<=n;i++)
	    {
	      tmp_vec(i) = R_vec_mon_sup(i); 
	    }
	  for(i=1;i<=p;i++)
	    {
	      tmp_vec(i+n) = p_vec_mon_sup(i); 
	    }
	  tmp_vec(n+p+1) = t_int_mon_sup;
	  SetCol(states_sup,1,tmp_vec);
	  Initialize(out_sup,upper_bounds(eq_i));

	  for(cnt=1;cnt<=Max_split;cnt++)
	    {
	      // determine index of candidate to be split (smallest infimum in out_inf)
	      best_sup = out_sup(1);
	      best_interval = 1;
	      for(i=1;i<=cnt;i++)
		{
		  if (out_sup(i)>best_sup)
		    {
		      best_sup = out_sup(i);
		      best_interval = i;
		    }
		}
	      
	      gradient_eq_i_sup = Col(grad_sup,best_interval);
	      candidate1 = Col(states_sup,best_interval);
	      candidate2 = Col(states_sup,best_interval);
	      if (Max(Diam(candidate1))<1e-10)
		{
		  break;
		}
	      
	      best_component = 1;
	      best_sensitivity = Diam(gradient_eq_i_sup(1))*Diam(candidate1(1)); 
	      for(i=1;i<=n+p+1;i++)
		{
		  if ((Diam(gradient_eq_i_sup(i))*Diam(candidate1(i)))>best_sensitivity)
		    {
		      best_sensitivity = (Diam(gradient_eq_i_sup(i))*Diam(candidate1(i)));
		      best_component = i;
		    }
		}
	      candidate1(best_component) = Hull(Inf(candidate1(best_component)),Mid(candidate1(best_component))); 
	      candidate2(best_component) = Hull(Mid(candidate2(best_component)),Sup(candidate2(best_component)));
	      
	      for(i=1;i<=n;i++)
		{
		  R_vec_mon_sup(i) = candidate1(i);
		}
	      for(i=1;i<=p;i++)
		{
		  p_vec_mon_sup(i) = candidate1(i+n); 
		}
	      t_int_mon_sup = candidate1(n+p+1);

	      MonotonicityTestSup(x_app_vec, dx_app_vec, R_vec_mon_sup, p_vec_mon_sup, t_int_mon_sup, gradient_eq_i_sup, upper_bounds, n, p, eq_i);
	      SetCol(grad_sup,best_interval,gradient_eq_i_sup);
	      SetCol(states_sup,best_interval,candidate1);
	      out_sup(best_interval) = upper_bounds(eq_i);

	      for(i=1;i<=n;i++)
		{
		  R_vec_mon_sup(i) = candidate2(i);
		}
	      for(i=1;i<=p;i++)
		{
		  p_vec_mon_sup(i) = candidate2(i+n); 
		}
	      t_int_mon_sup = candidate2(n+p+1);

	      MonotonicityTestSup(x_app_vec, dx_app_vec, R_vec_mon_sup, p_vec_mon_sup, t_int_mon_sup, gradient_eq_i_sup, upper_bounds, n, p, eq_i);
	      
	      SetCol(grad_sup,cnt+1,gradient_eq_i_sup);
	      SetCol(states_sup,cnt+1,candidate2);
	      out_sup(cnt+1) = upper_bounds(eq_i);
	    }
	  upper_bounds(eq_i) = Max(out_sup);
	} 
    }

  if (use_monotonicity_test==1)
    {
      d_R_MON = Hull(lower_bounds,upper_bounds);
      Intersection_exists = Intersection(d_R,d_R_MP,d_R_MON);
      return d_R; 
    }
  else
    {
      d_R = d_R_MP;
      return d_R;
    }
}


INTERVAL MVR_d_R_i(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR p_vec, INTERVAL t_int, INTERVAL_VECTOR R_plot, INTERVAL_VECTOR& gradient_eq_i, int n, int p, int eq_i) 
{ 
  F<INTERVAL> f_xR, RS_naiv; 
  INTERVAL d_R_naiv, d_R, RS_mid, d_R_mid; 
  INTERVAL_VECTOR diff_vector(n+p+1);
  int i; 

  f_xR = state_eq_F_i(x_app_vec, dx_app_vec, t_int, p_vec, R_plot, eq_i,n,p);
  RS_naiv = -dx_app_vec(eq_i) + f_xR; 
  d_R_naiv = RS_naiv.x(); 

  for(i=1;i<=n+p+1;i++) 
    { 
      gradient_eq_i(i) = RS_naiv.d(i-1);  
    }

  //   mean-vale rule: 
  for(i=1;i<=n;i++)
    {
      diff_vector(i) = R_plot(i) - Mid(R_plot(i)); 
    }
  for(i=1;i<=p;i++)
    {
      diff_vector(i+n) = p_vec(i) - Mid(p_vec(i)); 
    }
  diff_vector(n+p+1) = t_int - Mid(t_int);

  RS_mid = -dx_app_vec(eq_i) + state_eq_mid_i(x_app_vec,dx_app_vec,t_int,p_vec,R_plot,eq_i,n,p);
  d_R_mid = RS_mid + gradient_eq_i*diff_vector; 
  
  Intersection_exists = Intersection(d_R, d_R_naiv, d_R_mid);	// Improvement of enclosure of d_R by intersection of d_R_naiv and d_R_mid 
  //	Intersection has to exist here: otherwise, there is a programming error! 

  return d_R; 
}


void MonotonicityTestInf(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR& R_vec_mon_inf, INTERVAL_VECTOR& p_vec_mon_inf, INTERVAL& t_int_mon_inf, INTERVAL_VECTOR& gradient_eq_i_inf, VECTOR& lower_bounds, int n, int p, int eq_i)
{
  int i;
  bool calc_mon;

  for(i=1;i<=n+p+1;i++)
    { 
      calc_mon = 0;
      if(Inf(gradient_eq_i_inf(i))>=0.0)
	{
	  calc_mon = 1;
	  if (i<=n)
	    {
	      R_vec_mon_inf(i) = Hull(Inf(R_vec_mon_inf(i)));
	    } 
	  if ((i>n)&&(i<=n+p))
	    {
	      p_vec_mon_inf(i-n) = Hull(Inf(p_vec_mon_inf(i-n)));
	    } 
	  if (i==n+p+1)
	    {
	      t_int_mon_inf = Hull(Inf(t_int_mon_inf));
	    }
	}
      if(Sup(gradient_eq_i_inf(i))<=0.0)
	{
	  calc_mon = 1;
	  if (i<=n)
	    {
	      R_vec_mon_inf(i) = Hull(Sup(R_vec_mon_inf(i)));
	    } 
	  if ((i>n)&&(i<=n+p))
	    {
	      p_vec_mon_inf(i-n) = Hull(Sup(p_vec_mon_inf(i-n)));
	    } 
	  if (i==n+p+1)
	    {
	      t_int_mon_inf = Hull(Sup(t_int_mon_inf));
	    }
	}
    }
  if (calc_mon==1)
    {
      lower_bounds(eq_i)= Inf(MVR_d_R_i(x_app_vec, dx_app_vec, p_vec_mon_inf, t_int_mon_inf, R_vec_mon_inf, gradient_eq_i_inf, n, p, eq_i));
    }
}



void MonotonicityTestSup(VECTOR x_app_vec, VECTOR dx_app_vec, INTERVAL_VECTOR& R_vec_mon_sup, INTERVAL_VECTOR& p_vec_mon_sup, INTERVAL& t_int_mon_sup, INTERVAL_VECTOR& gradient_eq_i_sup, VECTOR& upper_bounds, int n, int p, int eq_i)
{
  int i;
  bool calc_mon;

  for(i=1;i<=n+p+1;i++)
    { 
      calc_mon = 0;
      if(Inf(gradient_eq_i_sup(i))>=0.0)
	{
	  calc_mon = 1;
	  if (i<=n)
	    {
	      R_vec_mon_sup(i) = Hull(Sup(R_vec_mon_sup(i)));
	    } 
	  if ((i>n)&&(i<=n+p))
	    {
	      p_vec_mon_sup(i-n) = Hull(Sup(p_vec_mon_sup(i-n)));
	    } 
	  if (i==n+p+1)
	    {
	      t_int_mon_sup = Hull(Sup(t_int_mon_sup));
	    }
	}
      if(Sup(gradient_eq_i_sup(i))<=0.0)
	{
	  calc_mon = 1;
	  if (i<=n)
	    {
	      R_vec_mon_sup(i) = Hull(Inf(R_vec_mon_sup(i)));
	    } 
	  if ((i>n)&&(i<=n+p))
	    {
	      p_vec_mon_sup(i-n) = Hull(Inf(p_vec_mon_sup(i-n)));
	    } 
	  if (i==n+p+1)
	    {
	      t_int_mon_sup = Hull(Inf(t_int_mon_sup));
	    }
	}
    }
  if (calc_mon==1)
    {
      upper_bounds(eq_i)= Sup(MVR_d_R_i(x_app_vec, dx_app_vec, p_vec_mon_sup, t_int_mon_sup, R_vec_mon_sup, gradient_eq_i_sup, n, p, eq_i));
    }
}




  //	--------------------------------------------------------------------------------------------------------------------------
  //	Iterative computation of R	
  //	--------------------------------------------------------------------------------------------------------------------------

void compute_R(int& Number, int& Number_min, int& Number_max, INTERVAL_VECTOR t1_int, INTERVAL_MATRIX& R_plot, INTERVAL_MATRIX& d_R, INTEGER_VECTOR& valid_step, INTERVAL_VECTOR par_vec, INTERVAL_VECTOR initial_encl, INTERVAL_MATRIX x_app_numeric_int, MATRIX x_app_numeric_low, MATRIX dx_app_numeric1, double Stepsize, double g, int number_rep, int number_rep_max, bool use_monotonicity_test, int Max_split, bool& error, bool& ready, int n, int p)
{
  int i, j, k, cnt=1, Number_max_old=0, slow=0, Number_min_old=0, split_exp=40, cnt_exp, split_number_int, split_number_comp;
  bool eval_exp, exp_incl, exp_diam_small, break_exp;
  INTERVAL_VECTOR R_int(n), R_plot_old(n), d_R_i(n), R_plot_i(n), R_tmp(n), R_start(n), coeff_exp(n), coeff_exp_old(n), coeff_exp_tmp1(n), exp_encl(n), par_vec_exp(n), exp_vec_old1(n), exp_vec_new1(n), exp_vec_old2(n), exp_vec_new2(n);
  VECTOR eval_exp_vec(split_exp), vol_exp_vec(split_exp);
  INTERVAL_MATRIX old_encl_split(n,split_exp), new_encl_exp(n,split_exp);

  INTERVAL int_TMP;
  INTERVAL_VECTOR hull_encl_new(n), hull_encl_new1(n);
  double vol_encl_new, vol_encl_new1;
  bool split_part2=0, crit = 0;;

  double variation_of_g, vol_max, opt_comp;			  

  FILE *file_R_plot_tmp;
  FILE *file_R_plot_ex_tmp;
  file_R_plot_tmp = fopen("R_plot_tmp.txt","w");
  file_R_plot_ex_tmp = fopen("R_plot_ex_tmp.txt","w");
  fclose(file_R_plot_tmp);
  fclose(file_R_plot_ex_tmp);

  R_start = initial_encl-Col(x_app_numeric_low,1);

  while (1)
    {
      cnt = cnt + 1;		// Number of steps

      //	Initialization of R0 = R(Number_min) for integration of d_R:
      if (Number_min > 1)
	{
	  R_int = Col(R_plot,Number_min-1);
	}
      else
	{
	  R_int = R_start;
	}

      Number_max_old = Number_max;
      Number_min_old = Number_min;
      Number_max = Number;

      //	Re-evaluation of R from Number_min:
      for(i=Number_min;i<=Min(Number,Number_min+20);i++)  //  Re-evaluation is only necessary from i=Number_min on
	{

	  if (i>1)
	    {
	      R_plot_i = Col(R_plot,i-1)+(t1_int(i)-Inf(t1_int(i)))*Col(d_R,i);
	    }
	  else
	    {
	      R_plot_i = R_start+(t1_int(i)-Inf(t1_int(i)))*Col(d_R,i);
	    }
	 	  
	  break_diam_R_large=0;
	  for (j=1;j<=n;j++)
	    {
	      if (Diam(R_plot_i(j)) > max_diam_R)
		{
		  break_diam_R_large = 1;
		  break;
		}
	    }
	  if (break_diam_R_large==1)
	    {
	      Number_max = i;
	      printf("break bound %d\n",i);
	      break;
	    }

	  tinf = Inf(t1_int(i)); 
	  d_R_i = d_R_computation(Col(x_app_numeric_low,i), Col(dx_app_numeric1,i), par_vec, t1_int(i), R_plot_i, n, p, use_monotonicity_test, Max_split);
	   
	  if (!Intersection_exists)
	    break;		// quitting for-loop
	   
	  SetCol(d_R,i,d_R_i); // integration of d_R ist still necessary ...
	  
	  //	Save old values to check whether state enclosures can be improved by iteration	   
	  R_plot_old = Col(R_plot,i);
	  	   
	  //	Integration of d_R with respect to time
	  R_int = R_int + Stepsize*Col(d_R,i);

	  //	Save enclosres R in the matrix R_plot (one column for each point of time):
	  SetCol(R_plot,i,R_int);

	  if ( ((i==1)&&(valid_step(i)==0)) || ((i>1)&&(valid_step(i)==0)&&(valid_step(i-1)==1)))
	    {
	      valid_step(i)=1;
	      if (!(Col(R_plot,i)<=R_plot_old))
		{
		  valid_step(i)=0;
		}
	    }
	  else
	    { 
	      // comparision of variation rates for all R(i) to determine Number_min:
	      Intersection(R_tmp,Col(R_plot,i),R_plot_old);
	      SetCol(R_plot,i,R_tmp);
	      eval_exp=EXP_RUN;
	      if (eval_exp==1)
		{
		  Initialize(eval_exp_vec,0.0);
		  if (i>1)
		    {
		      exp_vec_old1 = Col(R_plot,i-1);
		    }
		  else
		    {
		      exp_vec_old1 = R_start;
		    }
		  exp_vec_new1 = Col(R_plot,i);
		  SetCol(old_encl_split,1,exp_vec_old1);
		  SetCol(new_encl_exp,1,exp_vec_new1);
		}

	      for (cnt_exp=1;cnt_exp<=split_exp;cnt_exp++)
		{
		  if ((i<Number)&&(EXP_RUN==1))
		    {
		      eval_exp_vec(cnt_exp)=1.0;
		      if (cnt_exp==1)
			{
			  vol_exp_vec(1) = 1.0;
			  hull_encl_new = Col(new_encl_exp,1);
			  vol_encl_new = 1.0;
			  for (k=1;k<=n;k++)
			  {
				vol_encl_new *= Diam(hull_encl_new(k));
			  }

			  for (j=1;j<=n;j++)
			    {
			      vol_exp_vec(1) *= Diam(exp_vec_old1(j));
			    }
			  for (j=1;j<=n;j++)
			    {
			      if ( (0<=(exp_vec_old1(j)+x_app_numeric_low(j,i))) ||   
   				    (0<=(exp_vec_new1(j)+x_app_numeric_low(j,i+1))) )
				{
				  eval_exp_vec(cnt_exp)=0.0;
				  break;
				}
			    }
			  split_number_int = 1;
			}
		      else
			{
			  split_number_int = 1;
			  vol_max = vol_exp_vec(1)*(1-eval_exp_vec(1));
			  hull_encl_new = Col(new_encl_exp,1);
			  for (k=1;k<=cnt_exp-1;k++)
			    {
			      hull_encl_new = Hull(hull_encl_new,Col(new_encl_exp,k));
			      if ((vol_exp_vec(k)*(1-eval_exp_vec(k))) > vol_max)
				{
				  vol_max = vol_exp_vec(k)*(1-eval_exp_vec(k));
				  split_number_int = k;
				}
			    }

			  crit = 0;
/*			  for (k=1; k<=n; k++)
			    { crit = crit || (Diam(old_encl_split(k,split_number_int))<1e-3*Diam(hull_encl_new(k))); }
*/
			  if ( crit || (split_part2==1) )
			  {
			    split_part2 = 1;
			    vol_max = vol_exp_vec(1);
			    hull_encl_new = Col(new_encl_exp,1);
			    for (k=1;k<=cnt_exp-1;k++)
			    {
			      hull_encl_new = Hull(hull_encl_new,Col(new_encl_exp,k));
			      if ((vol_exp_vec(k)) > vol_max)
				{
				  vol_max = vol_exp_vec(k);
				  split_number_int = k;
				}
			    }
			  }

			  exp_vec_old1 = Col(old_encl_split,split_number_int);
			  exp_vec_old2 = Col(old_encl_split,split_number_int);
			  exp_vec_new1 = Col(new_encl_exp,split_number_int);
			  exp_vec_new2 = Col(new_encl_exp,split_number_int);

			  vol_encl_new = 1.0;
			  for (k=1;k<=n;k++)
			  {
				vol_encl_new *= Diam(hull_encl_new(k));
			  }

			  split_number_comp = 1;
			  for (j=1;j<=n;j++)
			    {
			      if ( (0<=(exp_vec_old1(j)+x_app_numeric_low(j,i))) ||
				    (0<=(exp_vec_new1(j)+x_app_numeric_low(j,i+1))) )
				{
				  split_number_comp = j;
				  break;
				}
			    }

			  exp_vec_old1(split_number_comp) = Hull(Inf(exp_vec_old1(split_number_comp)),Mid(exp_vec_old1(split_number_comp)));
			  exp_vec_old2(split_number_comp) = Hull(Mid(exp_vec_old2(split_number_comp)),Sup(exp_vec_old2(split_number_comp)));

			  tinf = Inf(t1_int(i)); 
			  R_plot_i = exp_vec_old1+(t1_int(i)-Inf(t1_int(i)))*Col(d_R,i);
			  d_R_i = d_R_computation(Col(x_app_numeric_low,i), Col(dx_app_numeric1,i), par_vec, t1_int(i), R_plot_i, n, p, use_monotonicity_test, Max_split);
			  Intersection(exp_vec_new1,exp_vec_new1,exp_vec_old1+Stepsize*d_R_i);

			  tinf = Inf(t1_int(i)); 
			  R_plot_i = exp_vec_old2+(t1_int(i)-Inf(t1_int(i)))*Col(d_R,i);
			  d_R_i = d_R_computation(Col(x_app_numeric_low,i), Col(dx_app_numeric1,i), par_vec, t1_int(i), R_plot_i, n, p, use_monotonicity_test, Max_split);
			  Intersection(exp_vec_new2,exp_vec_new2,exp_vec_old2+Stepsize*d_R_i);

			  SetCol(old_encl_split,split_number_int,exp_vec_old1);
			  SetCol(new_encl_exp,split_number_int,exp_vec_new1);

			  SetCol(old_encl_split,cnt_exp,exp_vec_old2);
			  SetCol(new_encl_exp,cnt_exp,exp_vec_new2);

			  vol_exp_vec(split_number_int) = 1.0;
			  for (j=1;j<=n;j++)
			    {
			      vol_exp_vec(split_number_int) *= Diam(exp_vec_old1(j));
			    }

			  vol_exp_vec(cnt_exp) = 1.0;
			  for (j=1;j<=n;j++)
			    {
			      vol_exp_vec(cnt_exp) *= Diam(exp_vec_old2(j));
			    }

			eval_exp_vec(split_number_int)=1.0; // **************
			  for (j=1;j<=n;j++)
			    {
			      if ( Intersection(int_TMP,SymHull(1e-2)*Diam(hull_encl_new(j)),(exp_vec_old1(j)+x_app_numeric_low(j,i))) ||
				    Intersection(int_TMP,SymHull(1e-2)*Diam(hull_encl_new(j)),(exp_vec_new1(j)+x_app_numeric_low(j,i+1))) ) 
				{
				  eval_exp_vec(split_number_int)=0.0;
				  break;
				}
			    }

			eval_exp_vec(cnt_exp)=1.0; // **************
			  for (j=1;j<=n;j++)
			    {
			      if ( Intersection(int_TMP,SymHull(1e-2),(exp_vec_old2(j)+x_app_numeric_low(j,i))) ||
				    Intersection(int_TMP,SymHull(1e-2),(exp_vec_new2(j)+x_app_numeric_low(j,i+1))) ) 
				{
				  eval_exp_vec(cnt_exp)=0.0;
				  break;
				}
			    }
			}

		      if (eval_exp_vec(split_number_int)==1.0)
			{
			  coeff_exp = coeff_exp_init;
			  coeff_exp_old = coeff_exp;
			  par_vec_exp = exp_vec_old1+Col(x_app_numeric_low,i);
			  exp_incl = 0;

			  for (k=1;k<=100;k++)
			    {
			      for (j=1;j<=n;j++)
			    	{
			      	  exp_encl(j)  = par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))));
			      	  if (Intersection(int_TMP,SymHull(1e-8),exp_encl(j)))
			             { eval_exp_vec(split_number_int)=0.0; }
			    	}

			      if (eval_exp_vec(split_number_int)==0.0)
				break;

			      mode_old = 0;
			      coeff_exp = d_R_computation(0*Col(x_app_numeric_low,i), 0*Col(dx_app_numeric1,i), par_vec_exp, t1_int(i), coeff_exp, n, p, use_monotonicity_test, Max_split);
			      mode_old = 1;

			      mode_old = 0;
 			      coeff_exp_tmp1 = d_R_computation(0*Col(x_app_numeric_low,i), 0*Col(dx_app_numeric1,i), exp_encl, t1_int(i), 0*coeff_exp, n, p, use_monotonicity_test, Max_split);
			      mode_old = 1;

			      Intersection(coeff_exp,coeff_exp,coeff_exp_tmp1);

			      mode_old = 1;

			      if ((coeff_exp<=coeff_exp_old)&&(exp_incl==0))
				{
				  exp_incl = 1;
				}

			      for (j=1;j<=n;j++)
				{
				  if ( Diam(par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))))) >max_diam_R )
				    {
				      eval_exp_vec(split_number_int) = 0.0;
				      break;
				    }
				}

			      if (eval_exp_vec(split_number_int)==0.0)
				{
				  break;
				}
			      else
				{
				  Intersection(coeff_exp,coeff_exp,coeff_exp_old);
				  for (j=1;j<=n;j++)
				    {
				      exp_encl(j)  = par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))));
				    }

				  exp_diam_small = 1;
				  for (j=1;j<=n;j++)
				    {
				      if ( Diam(coeff_exp(j)) > g* Diam(coeff_exp_old(j)) )
					{
					  exp_diam_small = 0;
					  break;
					}
				    }
				}

			      if (exp_diam_small==1)
				{
				  break;
				}
			      else
				{
				  coeff_exp_old = coeff_exp;
				}
			    }

			  if ((exp_incl==1)&&(exp_diam_small==1))
			    {
			      for (j=1;j<=n;j++)
				{
				  exp_encl(j) = par_vec_exp(j)*Exp(coeff_exp(j)*Diam(t1_int(i)));
				}

			      eval_exp_vec(split_number_int)=Intersection(exp_encl,exp_vec_new1,exp_encl-Col(x_app_numeric_low,i+1));
			      if (eval_exp_vec(split_number_int)==1.0)
				{
				  SetCol(new_encl_exp,split_number_int,exp_encl);
				}
			    }
			}

		      if ((eval_exp_vec(cnt_exp)==1)&&(cnt_exp>1))
			{
			  coeff_exp = coeff_exp_init;
			  coeff_exp_old = coeff_exp;
			  par_vec_exp = exp_vec_old2+Col(x_app_numeric_low,i);
			  exp_incl = 0;
			  
			  for (k=1;k<=100;k++)
			    {
			      for (j=1;j<=n;j++)
			        {
			           exp_encl(j)  = par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))));
			           if (Intersection(int_TMP,SymHull(1e-8),exp_encl(j)))
			              { eval_exp_vec(cnt_exp)=0.0; }
			        }

			      if (eval_exp_vec(cnt_exp)==0.0)
				break;

			      mode_old = 0;
			      coeff_exp = d_R_computation(0*Col(x_app_numeric_low,i), 0*Col(dx_app_numeric1,i), par_vec_exp, t1_int(i), coeff_exp, n, p, use_monotonicity_test, Max_split);
			      mode_old = 1;

			      mode_old = 0;
 			      coeff_exp_tmp1 = d_R_computation(0*Col(x_app_numeric_low,i), 0*Col(dx_app_numeric1,i), exp_encl, t1_int(i), 0*coeff_exp, n, p, use_monotonicity_test, Max_split);
			      mode_old = 1;

			      Intersection(coeff_exp,coeff_exp,coeff_exp_tmp1);

			      mode_old = 1;

			      if ((coeff_exp<=coeff_exp_old)&&(exp_incl==0))
				{
				  exp_incl = 1;
				}
			      
			      for (j=1;j<=n;j++)
				{
				  if ( Diam(par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))))) >max_diam_R )
				    {
				      eval_exp_vec(cnt_exp) = 0.0;
				      break;
				    }
				}
			      
			      if (eval_exp_vec(cnt_exp)==0.0)
				{
				  break;
				}
			      else
				{
				  Intersection(coeff_exp,coeff_exp,coeff_exp_old);
				  for (j=1;j<=n;j++)
				    {
				      exp_encl(j)  = par_vec_exp(j)*Exp(coeff_exp(j)*(t1_int(i)-Inf(t1_int(i))));
				    }
				  exp_diam_small = 1;

				  for (j=1;j<=n;j++)
				    {
				      if ( Diam(coeff_exp(j)) > g* Diam(coeff_exp_old(j)) )
					{
					  exp_diam_small = 0;
					  break;
					}
				    }
				}
			      
			      if (exp_diam_small==1)
				{
				  break;
				}
			      else
				{
				  coeff_exp_old = coeff_exp;
				}
			    }

			  if ((exp_incl==1)&&(exp_diam_small==1))
			    {
			      for (j=1;j<=n;j++)
				{
				  exp_encl(j) = par_vec_exp(j)*Exp(coeff_exp(j)*Diam(t1_int(i)));
				}

			      eval_exp_vec(cnt_exp)=Intersection(exp_encl,exp_vec_new2,exp_encl-Col(x_app_numeric_low,i+1));

			      if (eval_exp_vec(cnt_exp)==1.0)
				{
				  SetCol(new_encl_exp,cnt_exp,exp_encl);
				}
			    }
			}

// 			if (split_part2==1)
			{
			    hull_encl_new1 = Col(new_encl_exp,1);
			    for (k=1;k<=cnt_exp;k++)
			    {
			      hull_encl_new1 = Hull(hull_encl_new1,Col(new_encl_exp,k));
			    }
			}

			vol_encl_new1 = 1.0;
			double max_diam_encl = Diam(hull_encl_new1(1));
			for (k=1;k<=n;k++)
			{
			     vol_encl_new1 *= Diam(hull_encl_new1(k));
			     if (max_diam_encl<Diam(hull_encl_new1(k)))
				{ max_diam_encl=Diam(hull_encl_new1(k)); }
			}

		      break_exp=1;
		      for (j=1;j<=cnt_exp;j++)
			{
			  if (eval_exp_vec(j)==0.0)
			    {
			      break_exp=0;
			    }
			}

			if (max_diam_encl<1e-4) //EPS_EXP)
			{
				break_exp=1;
			}

/*		      if ((break_exp==1)||(split_part2)&&(vol_encl_new1/vol_encl_new>g))
			break;*/
		      if ((break_exp==1)||(vol_encl_new1/(vol_encl_new+EPS)>g)&&(cnt_exp>2) ) //||(vol_encl_new<EPS))
			break;
		    }
		}

		if (cnt_exp>split_exp)
		   cnt_exp=split_exp;

	      exp_vec_new1 = Col(new_encl_exp,1);
	      if ((EXP_RUN)&&(i<Number))
		{
		  for (j=1;j<=cnt_exp;j++)
		    {

			if (DEBUG==1)
			{
				cout << "j = " << j << "Col(new_encl_exp,j) = " << Col(new_encl_exp,j) << endl;
			}
		      exp_vec_new1 = Hull(exp_vec_new1,Col(new_encl_exp,j));
		    }
		if (DEBUG==1)
		{
			cout << "exp_vec_new1 = " << exp_vec_new1 << endl;
			cout << "Col(R_plot,i) = " << Col(R_plot,i) << endl;
		}

 		  Intersection(exp_vec_new1,exp_vec_new1,Col(R_plot,i));
		  SetCol(R_plot,i,exp_vec_new1);
		R_int = Col(R_plot,i);
/*
              for (j=i+1;j<=Min(Number,i+10);j++)  // j = i+1 ....
		{
		  if (j>1)
		    {
		      R_tmp = Col(R_plot,j);
		      Intersection(R_tmp,R_tmp,Col(R_plot,j-1) + Stepsize*Col(d_R,j));
		      SetCol(R_plot,j,R_tmp);
		    }
		  else
		    {
		      SetCol(R_plot,j,R_start + Stepsize*Col(d_R,j));
		    }
		}
*/

		}
	      
// 		DEBUG = 0;

	      if (Number_min==i)
		{
		  variation_of_g = BiasPosInf;
		  for(j=1;j<=n;j++)
		    {
		      if (((Diam(R_plot_old(j))<EPS) && (Diam(R_plot(j,i))<EPS))  ||   	
			   (((Diam(R_plot_old(j))<EPS_EXP) && (Diam(R_plot(j,i))<EPS_EXP))))
			{
			  variation_of_g =  min( variation_of_g , 1.0);
			}
		      else
			{
			  variation_of_g = min( variation_of_g , Diam(R_plot(j,i))/(Diam(R_plot_old(j))+EPS) ); // worst variation rate
			}
		    }
		  // if the worst variation rate is larger than g, 
		  // all state enclusures until Number_min are not re-evaluated in further iterations
		  if ((variation_of_g > g))
		    Number_min = i+1;
		}
	      
	      // Compute time step Number_max, where enclosures are becoming wider! (Initial enclosure was not large enough)
	      Number_max = i; // min(Number_max, i);
	    }		
       
	  if (i>Number_max)
	    {
	      break;
	    }	

	  Number_max = 0;
	  for (j=1;j<=Number;j++)
	    {
	      if (valid_step(j)==1)
		{
		  Number_max++;
		}
	      else
		{
		  break;
		}
	    }
  			
	  if (valid_step(i)==0)
	    {
	      error = 1;
	      number_rep++;
	      // for (j=i;j<=Number;j++)
	      for (j=i;j<=Min(Number,i+10);j++)
		{
		  SetCol(d_R,j,Mid(Col(d_R,j))+SymHull(0.51*Diam(Col(d_R,j))));

		  if (j>1)
		    {
		      SetCol(R_plot,j,Col(R_plot,j-1) + Stepsize*Col(d_R,j));
		    }
		  else
		    {
		      SetCol(R_plot,j,R_start + Stepsize*Col(d_R,j));
		    }
		}
	      
	      printf("Number of re-evaluations in error-case = %d\n",number_rep);
	      printf("Number_max = %d \t Number_max_old = %d\n",Number_max,Number_max_old);
	      printf("Number_max = %d \n",Number_max);
	      break;		// quitting for-loop
	    }
	  else
	    {
	      number_rep = 0;
	
              for (j=i+1;j<=Min(Number,i+10);j++)  // j = i+1 ....
		{
		  if (j>1)
		    {
		      R_tmp = Col(R_plot,j);
		      Intersection(R_tmp,R_tmp,Col(R_plot,j-1) + Stepsize*Col(d_R,j));
		      SetCol(R_plot,j,R_tmp);
// 		      SetCol(R_plot,j,Col(R_plot,j-1) + Stepsize*Col(d_R,j));
		    }
		  else
		    {
		      SetCol(R_plot,j,R_start + Stepsize*Col(d_R,j));
		    }
		}
            }

	  // If state enclosures are better that the desired precision until Number_max computation finished successfully
	  if ((Number == Number_min)&&(valid_step(Number)==1))
	    {
	      ready = 1;
	      break;		// quitting for-loop
	    }		

	  break_diam_R_large=0;
	  for (j=1;j<=n;j++)
	    {
	      if (Diam(R_plot(j,i)) > max_diam_R)
		{
		  break_diam_R_large = 1;
		}
	    }
	  if (break_diam_R_large==1)
	    {
	      Number_max = i;
	      break;
	    }	
	}	// end of for-loop


      if (save_every_step)
	{
	  file_R_plot_tmp = fopen("R_plot_tmp.txt","a");
	  file_R_plot_ex_tmp = fopen("R_plot_ex_tmp.txt","a");
	  for (i=Number_min_old+1;i<=Number_min;i++)
	    {
	      fprintf(file_R_plot_tmp,"%.10e \t",Sup(t1_int(i)));
	      fprintf(file_R_plot_ex_tmp,"%.10e \t",Sup(t1_int(i)));
	      
	      for(j=1;j<=n;j++)
		{
		  fprintf(file_R_plot_tmp,"%.10e \t %.10e \t",Inf(R_plot(j,i)),Sup(R_plot(j,i)));
		  fprintf(file_R_plot_ex_tmp,"%.10e \t %.10e \t",Inf(R_plot(j,i)+x_app_numeric_low(j,i)),Sup(R_plot(j,i)+x_app_numeric_low(j,i)));
		}
	      fprintf(file_R_plot_tmp,"\n");
	      fprintf(file_R_plot_ex_tmp,"\n");
	    }
	  fclose(file_R_plot_tmp);
	  fclose(file_R_plot_ex_tmp);
	}
      
      if ( (Number_min_old==Number_min)&&(Number_max_old==Number_max) )
	{
	  slow++;
	}
      else
	{
	  slow=0;
	}

      if (slow>10)
	{
	  ready = 1;
	  Number_max = Number_min;
	if (valid_step(Number_min+1)==1)
	{ Number_min++; ready = 0;}
	else 
	{ break; }
	}

      // errors
      if (error == 1)
	{
	  //	Maximum number_rep_max re-evaluations if bounds are not wide enough
	  if (number_rep < number_rep_max)
	    {	
	      printf("initialization not wide enough! \n");
	      printf("Automatic modification by recursion formula. \n\n");
	      error = 0;
	    }
	  else
	    break;		// quitting while-loop
	}
				
      // Iteration finished successfully
      if (ready == 1)
	{
	  printf("Ready!\n\n");
	  break;			// quitting while-loop
	}
      printf("counter: \t%d \t Number =  %d\n", cnt, Number);
      printf("variation_of_g at step Number_min=%d: \t%f \t Number_max = %d \n", Number_min, variation_of_g, Number_max);
	
    }	// end of while-loop

}




void compute_rot(INTERVAL_VECTOR initial_encl, int n)
{

VECTOR f_x0_vec(n), f_x0_red;
// FREALVEC x0(n),f_x0(n);
FINTERVALVEC x0(n),f_x0(n);
MATRIX JacMat(n,n), JacMat_red;
double tmp_jac;
int dim_red, i, j, i_red,j_red, valid_solve;
INTERVAL_VECTOR init_tmp_vec;

INTEGER_VECTOR indx_vec(n);

INTERVAL_MATRIX Rot_Matrix(n,n), Rot_Matrix_Inverse(n,n);
INTERVAL_MATRIX Rot_Matrix_total(n,n), Rot_Matrix_Inverse_total(n,n);

INTEGER_VECTOR indx_vec_old, indx_vec_tmp;
bool break_J=0;

Initialize(indx_vec,0);

for (i=1;i<=n;i++)
{
// 	x0[i-1] = Mid(initial_encl(i));  // zu korrigieren
	x0[i-1] = Hull(Mid(initial_encl(i)));
// 	x0[i-1] = initial_encl(i);
	x0[i-1].diff(i-1,n);
}

f_x0 = system_F(x0, n);

for (i=1;i<=n;i++)
{
// 	f_x0_vec(i)  = f_x0[i-1].x();		// zu korrigieren
	f_x0_vec(i)  = Mid(f_x0[i-1].x());
	tmp_jac = 0.0;
	for (j=1;j<=n;j++)
	{
// 		JacMat(i,j) = f_x0[i-1].d(j-1);		// zu korrigieren
		JacMat(i,j) = Mid(f_x0[i-1].d(j-1));
		tmp_jac += Abs(JacMat(i,j));
	}
	if (tmp_jac>0)
	{
		indx_vec(i) = 1;
	}
}

indx_vec_old = indx_vec;
while (1)
{
for (i=1;i<=n;i++)
{
	if (indx_vec(i)==1)
	{
		tmp_jac = 0.0;
		for (j=1;j<=n;j++)
		{
			if (indx_vec(j)==1)
			{
				tmp_jac+=Abs(JacMat(i,j));
			}
		}
		if (tmp_jac==0.0)
		{
			indx_vec(i) = 0;
		}
	}
}
indx_vec_tmp = indx_vec_old-indx_vec;
break_J = 1;
for (i=1;i<=n;i++)
{
	if (indx_vec_tmp(i)==1)
	{ break_J = 0; break;}
}
if (break_J)
{
	break; 
}
else
{
	indx_vec_old = indx_vec;
}
}

dim_red = 0;
for (i=1;i<=n;i++)
{
	if (indx_vec(i)==1)
	{
		dim_red++;
	}
}

Resize(JacMat_red,dim_red,dim_red);
Resize(f_x0_red,dim_red);
Resize(init_tmp_vec,dim_red);

i_red = 0;
j_red = 0;
for (i=1;i<=n;i++)
{
	if (indx_vec(i)==1)
	{
		i_red++;
		j_red = 0;
		f_x0_red(i_red) = f_x0_vec(i);
		init_tmp_vec(i_red) = Mid(initial_encl(i));
		for (j=1;j<=n;j++)
		{
			if (indx_vec(j)==1)
			{
				j_red++;
				JacMat_red(i_red,j_red) = JacMat(i,j);
			}
		}
	}
}

f_x0_red = Mid(LSS(JacMat_red, JacMat_red*Mid(init_tmp_vec)-f_x0_red, valid_solve));

Resize(shift_x,n);
Initialize(shift_x,0.0);
i_red = 0;
if (valid_solve==1)
{
	for (i=1;i<=n;i++)
	{
		if (indx_vec(i)==1)
		{
			i_red++;
			shift_x(i) = f_x0_red(i_red);
		}
	}
}

  gsl_matrix *jac_gsl = gsl_matrix_alloc(dim_red,dim_red);
  gsl_vector_complex *eig_val = gsl_vector_complex_alloc(dim_red);
  gsl_matrix_complex *eig_vec = gsl_matrix_complex_alloc(dim_red,dim_red);
  gsl_eigen_nonsymmv_workspace * workspace = gsl_eigen_nonsymmv_alloc(dim_red);

      for (i=1;i<=dim_red;i++)
	{
	  for (j=1;j<=dim_red;j++)
	    {
	      gsl_matrix_set(jac_gsl,i-1,j-1,JacMat_red(i,j));
	    }
	}

      gsl_eigen_nonsymmv(jac_gsl, eig_val, eig_vec, workspace);
      gsl_eigen_nonsymmv_free(workspace);

gsl_complex eval_i;
gsl_vector_complex *evec_i = gsl_vector_complex_alloc(dim_red);
gsl_complex z;

	Resize(Rot_Matrix,dim_red,dim_red);
	Resize(Rot_Matrix_Inverse,dim_red,dim_red);

	Initialize(Rot_Matrix,0.0);
	Initialize(Rot_Matrix_Inverse,0.0);

	INTERVAL_VECTOR tmp_vec_rot(dim_red);

i=1;
Resize(coeff_exp_init,n);
while (1)
{
    eval_i = gsl_vector_complex_get (eig_val, i-1);
    gsl_matrix_complex_get_col(evec_i,eig_vec,i-1);

    if (GSL_IMAG(eval_i)==0)  // Sortiere reelle Hauptvektoren,
	{
	for (j = 0; j < dim_red; j++)
	{
	z = gsl_vector_complex_get(evec_i, j);
	Rot_Matrix(j+1,i) = GSL_REAL(z);
	}
        i=i+1;
	}
    else                // Konjungiert komplexes Paerchen sonst.
	{
	for (j = 0; j < dim_red; j++)
	{
	z = gsl_vector_complex_get(evec_i, j);
	Rot_Matrix(j+1,i) = GSL_REAL(z);
	Rot_Matrix(j+1,i+1) = GSL_IMAG(z);
	}
        i=i+2;
	}
    if (i==dim_red+1)	
	break;
}

// inverse of rotation matrix

      for (i=1;i<=dim_red;i++)
	{
	  Initialize(tmp_vec_rot,0.0);
	  tmp_vec_rot(i) = 1.0;
	  tmp_vec_rot = ILSS(Rot_Matrix,tmp_vec_rot,valid_solve);
	  if (valid_solve==1)
	    {
	      SetCol(Rot_Matrix_Inverse,i,tmp_vec_rot);
	    }
	  else
	    {
	      break;
	    }
	}

	Initialize(Rot_Matrix_total,0.0);
	Initialize(Rot_Matrix_Inverse_total,0.0);

i_red = 0;
for (i=1;i<=n;i++)
{
	if (indx_vec(i)==1)
	{
		eval_i = gsl_vector_complex_get (eig_val, i_red);
// 		cout << GSL_REAL(eval_i) << endl;
// 		cout << GSL_IMAG(eval_i) << endl;
// 		coeff_exp_init(i) = Hull(0,10.0)*GSL_REAL(eval_i);
		i_red++;
		j_red = 0;
		for (j=1;j<=n;j++)
		{
			if (indx_vec(j)==1)
			{
				j_red++;
				Rot_Matrix_total(i,j) = Rot_Matrix(i_red,j_red);
				Rot_Matrix_Inverse_total(i,j) = Rot_Matrix_Inverse(i_red,j_red);
			}
		}
	}
	else
	{
		coeff_exp_init(i) = SymHull(0.1);
		Rot_Matrix_total(i,i) = 1.0;
		Rot_Matrix_Inverse_total(i,i) = 1.0;
	}
}

T_MAT  = Rot_Matrix_total;
IT_MAT = Rot_Matrix_Inverse_total;

gsl_vector_complex_free(eig_val);
gsl_vector_complex_free(evec_i);
gsl_matrix_complex_free(eig_vec);
gsl_matrix_free(jac_gsl);


for (i=1;i<=n;i++)
{
	x0[i-1] = initial_encl(i);
	x0[i-1].diff(i-1,n);
}

f_x0 = system_F(x0, n);

INTERVAL_VECTOR f_x0_ivec(n);
INTERVAL_MATRIX JacMat_i(n,n);

for (i=1;i<=n;i++)
{
	f_x0_ivec(i)  = f_x0[i-1].x();
	tmp_jac = 0.0;
	for (j=1;j<=n;j++)
	{
		JacMat_i(i,j) = f_x0[i-1].d(j-1);
	}
}


JacMat_i = Rot_Matrix_total*JacMat_i*Rot_Matrix_Inverse_total;

for (i=1;i<=n;i++)
{
	if (indx_vec(i)==1)
		coeff_exp_init(i) = JacMat_i(i,i)+SymHull(10.0);
	else
		coeff_exp_init(i) = JacMat_i(i,i)+SymHull(0.10);
}

}






